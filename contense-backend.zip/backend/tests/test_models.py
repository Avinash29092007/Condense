from datetime import date

import pytest
from sqlalchemy.exc import IntegrityError

from app.models import User, Topic, Task, Completion, DailyNote


def make_user(db, email='luna@example.com', username='luna'):
    user = User(username=username, email=email, display_name='Luna')
    user.set_password('correct horse battery staple')
    db.session.add(user)
    db.session.commit()
    return user


class TestUser:
    def test_password_is_hashed_not_plaintext(self, db):
        user = make_user(db)
        assert user.password_hash != 'correct horse battery staple'
        assert user.check_password('correct horse battery staple') is True
        assert user.check_password('wrong password') is False

    def test_email_must_be_unique(self, db):
        make_user(db, email='dup@example.com', username='one')
        dup = User(username='two', email='dup@example.com', display_name='Two')
        dup.set_password('whatever123')
        db.session.add(dup)
        with pytest.raises(IntegrityError):
            db.session.commit()

    def test_to_dict_matches_frontend_contract(self, db):
        user = make_user(db)
        data = user.to_dict()
        for key in ['id', 'name', 'email', 'avatarInitial', 'joinedAt', 'totalXp', 'currentStreak', 'longestStreak', 'onboarded']:
            assert key in data
        assert 'password_hash' not in data
        assert data['name'] == 'Luna'
        assert data['avatarInitial'] == 'L'
        assert data['onboarded'] is False

    def test_xp_cannot_go_negative_at_db_level(self, db):
        user = make_user(db)
        user.total_xp = -5
        db.session.add(user)
        with pytest.raises(IntegrityError):
            db.session.commit()


class TestTopic:
    def test_create_and_serialize(self, db):
        user = make_user(db)
        topic = Topic(user_id=user.id, name='Deep Work', color='accent', position=0)
        db.session.add(topic)
        db.session.commit()

        data = topic.to_dict()
        assert data['name'] == 'Deep Work'
        assert data['color'] == 'accent'
        assert data['order'] == 0
        assert 'createdAt' in data

    def test_invalid_color_rejected_at_db_level(self, db):
        user = make_user(db)
        topic = Topic(user_id=user.id, name='Bad Color', color='magenta', position=0)
        db.session.add(topic)
        with pytest.raises(IntegrityError):
            db.session.commit()

    def test_deleting_topic_cascades_to_tasks_and_completions(self, db):
        user = make_user(db)
        topic = Topic(user_id=user.id, name='Craft', color='good', position=0)
        db.session.add(topic)
        db.session.commit()

        task = Task(user_id=user.id, topic_id=topic.id, name='Write a page', xp=20, frequency='Daily')
        db.session.add(task)
        db.session.commit()

        completion = Completion(user_id=user.id, task_id=task.id, date=date.today(), points_awarded=20)
        db.session.add(completion)
        db.session.commit()

        assert Task.query.count() == 1
        assert Completion.query.count() == 1

        db.session.delete(topic)
        db.session.commit()

        assert Task.query.count() == 0
        assert Completion.query.count() == 0


class TestTask:
    def _topic(self, db, user):
        topic = Topic(user_id=user.id, name='Body', color='cyan', position=0)
        db.session.add(topic)
        db.session.commit()
        return topic

    def test_create_and_serialize_uses_topicId(self, db):
        user = make_user(db)
        topic = self._topic(db, user)
        task = Task(user_id=user.id, topic_id=topic.id, name='Move for 20 minutes', xp=15, frequency='Daily')
        db.session.add(task)
        db.session.commit()

        data = task.to_dict()
        assert data['topicId'] == topic.id
        assert data['name'] == 'Move for 20 minutes'
        assert data['xp'] == 15
        assert data['active'] is True

    def test_invalid_frequency_rejected(self, db):
        user = make_user(db)
        topic = self._topic(db, user)
        task = Task(user_id=user.id, topic_id=topic.id, name='Bad freq', xp=10, frequency='Hourly')
        db.session.add(task)
        with pytest.raises(IntegrityError):
            db.session.commit()

    def test_negative_xp_rejected(self, db):
        user = make_user(db)
        topic = self._topic(db, user)
        task = Task(user_id=user.id, topic_id=topic.id, name='Bad xp', xp=-5, frequency='Daily')
        db.session.add(task)
        with pytest.raises(IntegrityError):
            db.session.commit()


class TestCompletion:
    def _task(self, db, user):
        topic = Topic(user_id=user.id, name='Deep Work', color='accent', position=0)
        db.session.add(topic)
        db.session.commit()
        task = Task(user_id=user.id, topic_id=topic.id, name='Focus block', xp=40, frequency='Daily')
        db.session.add(task)
        db.session.commit()
        return task

    def test_duplicate_completion_same_day_rejected(self, db):
        user = make_user(db)
        task = self._task(db, user)
        today = date.today()

        db.session.add(Completion(user_id=user.id, task_id=task.id, date=today, points_awarded=40))
        db.session.commit()

        db.session.add(Completion(user_id=user.id, task_id=task.id, date=today, points_awarded=40))
        with pytest.raises(IntegrityError):
            db.session.commit()

    def test_same_task_different_days_allowed(self, db):
        user = make_user(db)
        task = self._task(db, user)
        db.session.add(Completion(user_id=user.id, task_id=task.id, date=date(2026, 1, 1), points_awarded=40))
        db.session.add(Completion(user_id=user.id, task_id=task.id, date=date(2026, 1, 2), points_awarded=40))
        db.session.commit()
        assert Completion.query.count() == 2

    def test_serialize_matches_frontend_shape(self, db):
        user = make_user(db)
        task = self._task(db, user)
        completion = Completion(user_id=user.id, task_id=task.id, date=date(2026, 1, 1), points_awarded=40)
        db.session.add(completion)
        db.session.commit()

        data = completion.to_dict()
        assert data['taskId'] == task.id
        assert data['date'] == '2026-01-01'


class TestDailyNote:
    def test_one_note_per_user_per_date(self, db):
        user = make_user(db)
        db.session.add(DailyNote(user_id=user.id, date=date(2026, 1, 1), content='Good day.'))
        db.session.commit()

        db.session.add(DailyNote(user_id=user.id, date=date(2026, 1, 1), content='Second note.'))
        with pytest.raises(IntegrityError):
            db.session.commit()

    def test_serialize(self, db):
        user = make_user(db)
        note = DailyNote(user_id=user.id, date=date(2026, 1, 1), content='Shipped the backend models.')
        db.session.add(note)
        db.session.commit()

        data = note.to_dict()
        assert data['date'] == '2026-01-01'
        assert data['content'] == 'Shipped the backend models.'


class TestUserDeletionCascade:
    def test_deleting_user_removes_everything(self, db):
        user = make_user(db)
        topic = Topic(user_id=user.id, name='Deep Work', color='accent', position=0)
        db.session.add(topic)
        db.session.commit()
        task = Task(user_id=user.id, topic_id=topic.id, name='Focus', xp=10, frequency='Daily')
        db.session.add(task)
        db.session.commit()
        db.session.add(Completion(user_id=user.id, task_id=task.id, date=date.today(), points_awarded=10))
        db.session.add(DailyNote(user_id=user.id, date=date.today(), content='Note'))
        db.session.commit()

        db.session.delete(user)
        db.session.commit()

        assert Topic.query.count() == 0
        assert Task.query.count() == 0
        assert Completion.query.count() == 0
        assert DailyNote.query.count() == 0

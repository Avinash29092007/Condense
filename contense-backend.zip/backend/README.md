# Contense — Backend (Flask API)

Backend for the Contense personal consistency tracker. Pairs with the
existing `streak/` Vite/React frontend — this repo never touches that
frontend, it only implements the API it already expects
(see `streak/src/services/api.js`).

## Status: Phase 2 complete

Phase 1 (app factory, config, extensions, error handlers, health check)
is unchanged and still passing. Phase 2 adds:

- Five SQLAlchemy models — `User`, `Topic`, `Task`, `Completion`,
  `DailyNote` — with relationships, cascading deletes, check constraints,
  and timestamps (`app/models/`)
- The first Alembic migration (`migrations/versions/`), generated and
  verified against a real SQLite file
- A `to_dict()` on every model that translates the backend's snake_case
  columns into the exact shape `streak/src/services/api.js` already
  expects (`topicId`, `order`, `createdAt`, `totalXp`, ...)
- 16 passing pytest tests covering hashing, uniqueness, check
  constraints, cascades, and the serialization contract
  (`tests/test_models.py`, `tests/conftest.py`)

Still nothing at the HTTP layer — no auth, no routes. That's Phase 3+.

### Models at a glance

| Model | Table | Key constraints |
|---|---|---|
| `User` | `users` | unique `email`, unique `username`, XP/streak columns never negative (DB check constraints), password stored only as a hash |
| `Topic` | `topics` | belongs to a `User`; `color` restricted to `accent`/`cyan`/`good` (matches the frontend's `ColorPicker`); deleting a topic cascades to its tasks |
| `Task` | `tasks` | belongs to a `User` and a `Topic`; `frequency` restricted to `Daily`/`Weekly`/`One-time`; `xp >= 0`; deleting a task cascades to its completions |
| `Completion` | `completions` | belongs to a `User` and a `Task`; **unique on `(user_id, task_id, date)`** — this is what makes `toggleCompletion` safe against duplicate-completion XP exploits at the database level; `points_awarded` freezes the XP granted at completion time so later task edits can't corrupt a refund |
| `DailyNote` | `daily_notes` | belongs to a `User`; unique on `(user_id, date)` |

Deleting a `User` cascades through all four other tables — verified by
`test_deleting_user_removes_everything`.

### A note on one bug caught during this phase

The `.env` from Phase 1 set `DATABASE_URL=sqlite:///contense.db` — a
*relative* SQLite URL. Flask resolves relative `sqlite:///` URLs against
its auto-created `instance/` folder, not the repo root, which silently
produced two different database files depending on how a command was
run (`contense.db` vs `instance/contense.db`) — one of them always
empty. `app/config.py` now rewrites any relative `sqlite:///` URL to an
absolute path under the backend root, so there is exactly one dev
database file, at a predictable location, regardless of `cwd` or
`instance_path`. This is covered by the "resolved DB URI" check run
before/after the fix, not by an automated test (there's nothing to
assert against without spinning up a second process).

## Running it

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env            # defaults are fine for local dev

flask --app run.py db upgrade   # create/upgrade the database schema
python run.py                   # http://localhost:5000
```

Verify it's alive:

```bash
curl http://localhost:5000/api/health
```

```json
{
  "success": true,
  "message": "Contense API is running",
  "data": { "status": "ok", "env": "development" }
}
```

Run the tests:

```bash
pytest tests/ -v
```

### Making a schema change later

```bash
flask --app run.py db migrate -m "Describe the change"
flask --app run.py db upgrade
```

## Configuration

All config comes from environment variables (see `.env.example`), loaded
via `python-dotenv`. Nothing is hardcoded:

| Variable | Purpose | Dev default |
|---|---|---|
| `SECRET_KEY` | Flask's general secret | insecure placeholder |
| `JWT_SECRET_KEY` | Signs JWTs | insecure placeholder |
| `DATABASE_URL` | SQLAlchemy URI | `sqlite:///contense.db` |
| `FRONTEND_URL` | Allowed CORS origin | `http://localhost:5173` |
| `FLASK_ENV` | `development` / `testing` / `production` | `development` |

To use Postgres later, just set:
```
DATABASE_URL=postgresql://user:password@localhost:5432/contense
```
No code changes needed — `app/config.py` normalizes the URL and hands it
straight to SQLAlchemy.

## Project structure

```
backend/
├── app/
│   ├── __init__.py       application factory
│   ├── config.py         env-driven config classes
│   ├── extensions.py     db, migrate, jwt, cors instances
│   ├── models/
│   │   ├── __init__.py   re-exports all models (registers metadata)
│   │   ├── user.py
│   │   ├── topic.py
│   │   ├── task.py
│   │   ├── completion.py
│   │   └── daily_note.py
│   ├── routes/             (empty — Phase 3+)
│   ├── services/           (empty — Phase 6+)
│   └── utils/
│       └── responses.py  success_response / error_response helpers
├── migrations/
│   └── versions/
│       └── 1d1cd074542e_initial_models_user_topic_task_.py
├── tests/
│   ├── conftest.py
│   └── test_models.py
├── .env.example
├── requirements.txt
├── run.py
└── README.md
```

## Next: Phase 3

Authentication — `POST /api/auth/register`, `POST /api/auth/login`,
`GET /api/auth/me`, `PUT /api/auth/profile`, `PUT /api/auth/change-password`,
returning `{ user, token }` exactly as `AuthContext.jsx` expects.

"""
Configuration objects for the Flask app.

Nothing in here is a real secret — actual values are read from the
environment (see .env.example). SQLite is the default for local
development; set DATABASE_URL to a postgresql:// URL to switch to
Postgres without any code changes.
"""

import os
from datetime import timedelta

from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

# Load .env once, at import time, so `flask run` / gunicorn / pytest all see it.
load_dotenv(os.path.join(BASE_DIR, '.env'))


def _database_url(default_filename='contense.db'):
    url = os.environ.get('DATABASE_URL')
    if url:
        # Some hosts (e.g. Heroku-style) hand out "postgres://" which
        # SQLAlchemy 1.4+/2.x no longer accepts — normalize it.
        if url.startswith('postgres://'):
            url = url.replace('postgres://', 'postgresql://', 1)
        # A *relative* sqlite:/// URL is resolved by Flask against its
        # instance/ folder, not the repo root — which silently produces
        # a second, empty database file if anyone runs commands from a
        # different cwd. Rewrite relative sqlite URLs to an absolute
        # path under BASE_DIR so there is exactly one dev database file,
        # always in the same place, regardless of cwd or instance_path.
        if url.startswith('sqlite:///') and not url.startswith('sqlite:////'):
            relative_path = url[len('sqlite:///'):]
            url = f"sqlite:///{os.path.join(BASE_DIR, relative_path)}"
        return url
    return f"sqlite:///{os.path.join(BASE_DIR, default_filename)}"


class BaseConfig:
    """Shared defaults. Do not instantiate directly."""

    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-me')
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'dev-jwt-secret-key-change-me')

    SQLALCHEMY_DATABASE_URI = _database_url()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {'pool_pre_ping': True}

    FRONTEND_URL = os.environ.get('FRONTEND_URL', 'http://localhost:5173')

    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=7)
    JWT_TOKEN_LOCATION = ['headers']
    JWT_HEADER_NAME = 'Authorization'
    JWT_HEADER_TYPE = 'Bearer'

    JSON_SORT_KEYS = False


class DevelopmentConfig(BaseConfig):
    DEBUG = True


class TestingConfig(BaseConfig):
    TESTING = True
    DEBUG = True
    # Always an isolated in-memory DB for tests, regardless of DATABASE_URL.
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)


class ProductionConfig(BaseConfig):
    DEBUG = False


CONFIG_BY_NAME = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
}


def get_config(name=None):
    name = name or os.environ.get('FLASK_ENV', 'development')
    return CONFIG_BY_NAME.get(name, DevelopmentConfig)

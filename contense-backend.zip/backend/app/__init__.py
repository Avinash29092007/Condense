"""
Application factory.

PHASE 1 scope only: Flask app creation, configuration, extension
initialization, database wiring, generic error handlers, and a health
check so the whole thing can be verified end-to-end before any real
models or routes exist.

Models (Phase 2), auth (Phase 3), and every resource blueprint
(Phase 4+) will each register themselves from here once they exist —
see the commented registration block at the bottom of create_app().
"""

from flask import Flask

from app.config import get_config
from app.extensions import db, migrate, jwt, cors
from app.utils.responses import error_response


def create_app(config_name=None):
    app = Flask(__name__)
    app.config.from_object(get_config(config_name))

    _init_extensions(app)
    _register_error_handlers(app)
    _register_health_check(app)

    # Import models so they register with SQLAlchemy's metadata before
    # any db.create_all() / `flask db migrate` runs. Must happen after
    # db.init_app(app) (inside _init_extensions) but before the app is
    # handed back to the caller.
    with app.app_context():
        from app import models  # noqa: F401

    # ── Blueprints get registered here as each phase adds them ──────────
    # from app.routes.auth import auth_bp
    # from app.routes.topics import topics_bp
    # from app.routes.tasks import tasks_bp
    # from app.routes.completions import completions_bp
    # from app.routes.dashboard import dashboard_bp
    # from app.routes.history import history_bp
    # from app.routes.statistics import statistics_bp
    # from app.routes.users import users_bp
    #
    # app.register_blueprint(auth_bp, url_prefix='/api/auth')
    # app.register_blueprint(topics_bp, url_prefix='/api/topics')
    # app.register_blueprint(tasks_bp, url_prefix='/api/tasks')
    # app.register_blueprint(completions_bp, url_prefix='/api')
    # app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    # app.register_blueprint(history_bp, url_prefix='/api/history')
    # app.register_blueprint(statistics_bp, url_prefix='/api/statistics')
    # app.register_blueprint(users_bp, url_prefix='/api/user')

    return app


def _init_extensions(app):
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)

    # Only the configured frontend origin may call the API, with
    # credentials support for the Authorization header.
    cors.init_app(
        app,
        resources={r"/api/*": {"origins": app.config['FRONTEND_URL']}},
        supports_credentials=True,
    )


def _register_error_handlers(app):
    @app.errorhandler(400)
    def bad_request(e):
        return error_response('Bad request', 400, str(e))

    @app.errorhandler(401)
    def unauthorized(e):
        return error_response('Authentication required', 401, str(e))

    @app.errorhandler(403)
    def forbidden(e):
        return error_response('You do not have access to this resource', 403, str(e))

    @app.errorhandler(404)
    def not_found(e):
        return error_response('Resource not found', 404, str(e))

    @app.errorhandler(405)
    def method_not_allowed(e):
        return error_response('Method not allowed', 405, str(e))

    @app.errorhandler(500)
    def internal_error(e):
        # Never leak internal exception details to the client.
        app.logger.exception('Unhandled server error')
        return error_response('Internal server error', 500, 'internal_error')

    @app.errorhandler(Exception)
    def unhandled_exception(e):
        app.logger.exception('Unhandled exception')
        return error_response('Internal server error', 500, 'internal_error')


def _register_health_check(app):
    @app.get('/api/health')
    def health():
        return {
            'success': True,
            'message': 'Contense API is running',
            'data': {'status': 'ok', 'env': app.config.get('ENV', 'unknown')},
        }

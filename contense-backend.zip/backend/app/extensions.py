"""
Extension instances live here, uninitialized. The application factory in
app/__init__.py calls `.init_app(app)` on each one. Keeping them in their
own module (instead of creating them inside __init__.py) is what lets
models/routes `from app.extensions import db` without circular imports.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_cors import CORS

db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()
cors = CORS()

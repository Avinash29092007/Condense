"""
Small helpers so every route returns the same JSON envelope:

    { "success": true,  "message": "...", "data": {...} }
    { "success": false, "message": "...", "error": "..." }

Phase 1 only wires this up for the generic error handlers (404/500/etc).
Route modules in later phases import `success_response` / `error_response`
directly.
"""

from flask import jsonify


def success_response(data=None, message='OK', status_code=200):
    payload = {'success': True, 'message': message, 'data': data}
    return jsonify(payload), status_code


def error_response(message='Something went wrong', status_code=400, error=None):
    payload = {'success': False, 'message': message, 'error': error or message}
    return jsonify(payload), status_code

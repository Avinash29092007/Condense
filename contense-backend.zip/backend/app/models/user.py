"""
User model.

Column names follow the backend's own snake_case convention
(display_name, total_xp, ...); `to_dict()` is what translates that into
the shape the frontend already expects from mockData/api.js
(name, totalXp, currentStreak, ...). Routes should always serialize
through `to_dict()` rather than exposing the model directly, so
`password_hash` never leaks.
"""

from datetime import datetime

from werkzeug.security import generate_password_hash, check_password_hash

from app.extensions import db


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    display_name = db.Column(db.String(120), nullable=False)

    total_xp = db.Column(db.Integer, nullable=False, default=0)
    current_streak = db.Column(db.Integer, nullable=False, default=0)
    longest_streak = db.Column(db.Integer, nullable=False, default=0)
    last_active_date = db.Column(db.Date, nullable=True)

    # Per-user onboarding state (deliberately not a global/app-wide flag —
    # each user completes onboarding independently). Consumed by the
    # onboarding endpoints in a later phase.
    onboarded = db.Column(db.Boolean, nullable=False, default=False)

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ── Relationships ────────────────────────────────────────────────────
    topics = db.relationship(
        'Topic', back_populates='user', cascade='all, delete-orphan', lazy='dynamic'
    )
    tasks = db.relationship(
        'Task', back_populates='user', cascade='all, delete-orphan', lazy='dynamic'
    )
    completions = db.relationship(
        'Completion', back_populates='user', cascade='all, delete-orphan', lazy='dynamic'
    )
    notes = db.relationship(
        'DailyNote', back_populates='user', cascade='all, delete-orphan', lazy='dynamic'
    )

    __table_args__ = (
        db.CheckConstraint('total_xp >= 0', name='ck_users_total_xp_non_negative'),
        db.CheckConstraint('current_streak >= 0', name='ck_users_current_streak_non_negative'),
        db.CheckConstraint('longest_streak >= 0', name='ck_users_longest_streak_non_negative'),
    )

    # ── Password helpers ────────────────────────────────────────────────
    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    # ── Serialization ────────────────────────────────────────────────────
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'name': self.display_name,
            'email': self.email,
            'avatarInitial': (self.display_name or self.username or '?')[:1].upper(),
            'joinedAt': self.created_at.date().isoformat() if self.created_at else None,
            'totalXp': self.total_xp,
            'currentStreak': self.current_streak,
            'longestStreak': self.longest_streak,
            'lastActiveDate': self.last_active_date.isoformat() if self.last_active_date else None,
            'onboarded': self.onboarded,
        }

    def __repr__(self):
        return f'<User id={self.id} email={self.email!r}>'

"""
DailyNote model. One note per (user, date), enforced with a unique
constraint — matches GET/POST /api/notes and PUT/DELETE /api/notes/<date>
from a later phase.
"""

from datetime import datetime

from app.extensions import db


class DailyNote(db.Model):
    __tablename__ = 'daily_notes'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)

    date = db.Column(db.Date, nullable=False, index=True)
    content = db.Column(db.Text, nullable=False, default='')

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ── Relationships ────────────────────────────────────────────────────
    user = db.relationship('User', back_populates='notes')

    __table_args__ = (
        db.UniqueConstraint('user_id', 'date', name='uq_daily_notes_user_date'),
    )

    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat() if self.date else None,
            'content': self.content,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self):
        return f'<DailyNote user_id={self.user_id} date={self.date}>'

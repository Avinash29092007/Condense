"""
Task model.

`topic_id` is the DB column; it serializes as `topicId` in `to_dict()`
to match createTask({ topicId, name, xp, frequency, description }) and
the rest of the frontend contract.
"""

from datetime import datetime

from app.extensions import db

ALLOWED_FREQUENCIES = ('Daily', 'Weekly', 'One-time')


class Task(db.Model):
    __tablename__ = 'tasks'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    topic_id = db.Column(db.Integer, db.ForeignKey('topics.id', ondelete='CASCADE'), nullable=False, index=True)

    name = db.Column(db.String(200), nullable=False)
    xp = db.Column(db.Integer, nullable=False, default=10)
    frequency = db.Column(db.String(20), nullable=False, default='Daily')
    description = db.Column(db.String(500), nullable=True, default='')
    active = db.Column(db.Boolean, nullable=False, default=True)
    position = db.Column(db.Integer, nullable=False, default=0)

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ── Relationships ────────────────────────────────────────────────────
    user = db.relationship('User', back_populates='tasks')
    topic = db.relationship('Topic', back_populates='tasks')
    completions = db.relationship(
        'Completion', back_populates='task', cascade='all, delete-orphan', lazy='dynamic'
    )

    __table_args__ = (
        db.CheckConstraint('xp >= 0', name='ck_tasks_xp_non_negative'),
        db.CheckConstraint(f"frequency in {ALLOWED_FREQUENCIES}", name='ck_tasks_frequency_allowed'),
    )

    def to_dict(self):
        return {
            'id': self.id,
            'topicId': self.topic_id,
            'name': self.name,
            'xp': self.xp,
            'frequency': self.frequency,
            'description': self.description or '',
            'active': self.active,
            'order': self.position,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self):
        return f'<Task id={self.id} name={self.name!r} topic_id={self.topic_id}>'

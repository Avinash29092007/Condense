"""
Topic model.

`position` is the DB column name (matches the spec's model list); it
serializes as `order` in `to_dict()` because that's what the frontend's
mockData/api.js already calls it (topic.order, reorderTopics(orderedIds)).
"""

from datetime import datetime

from app.extensions import db

# A small, curated palette rather than free-text colors — matches the
# frontend's ColorPicker in Topics.jsx (accent / cyan / good).
ALLOWED_COLORS = ('accent', 'cyan', 'good')


class Topic(db.Model):
    __tablename__ = 'topics'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)

    name = db.Column(db.String(120), nullable=False)
    color = db.Column(db.String(20), nullable=False, default='accent')
    description = db.Column(db.String(500), nullable=True)
    icon = db.Column(db.String(40), nullable=True)
    position = db.Column(db.Integer, nullable=False, default=0)

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ── Relationships ────────────────────────────────────────────────────
    user = db.relationship('User', back_populates='topics')
    tasks = db.relationship(
        'Task', back_populates='topic', cascade='all, delete-orphan', lazy='dynamic'
    )

    __table_args__ = (
        db.CheckConstraint(f"color in {ALLOWED_COLORS}", name='ck_topics_color_allowed'),
    )

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'color': self.color,
            'description': self.description,
            'icon': self.icon,
            'order': self.position,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self):
        return f'<Topic id={self.id} name={self.name!r} user_id={self.user_id}>'

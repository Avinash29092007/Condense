"""
Importing this package registers every model with SQLAlchemy's metadata,
which is what lets `flask db migrate` autogenerate and `db.create_all()`
(tests) see all five tables. Always import models via this package
(`from app.models import User`), not the individual submodules directly.
"""

from app.models.user import User
from app.models.topic import Topic, ALLOWED_COLORS
from app.models.task import Task, ALLOWED_FREQUENCIES
from app.models.completion import Completion
from app.models.daily_note import DailyNote

__all__ = [
    'User',
    'Topic',
    'ALLOWED_COLORS',
    'Task',
    'ALLOWED_FREQUENCIES',
    'Completion',
    'DailyNote',
]

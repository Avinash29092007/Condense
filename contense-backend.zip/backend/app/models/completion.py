"""
Completion model.

One row = one task marked done on one calendar day. The unique
constraint on (user_id, task_id, date) is the mechanism that makes
toggleCompletion() safe against double-completion/XP exploits at the
database level, not just in application logic.

`points_awarded` freezes how much XP this specific completion was worth
at the time it was created, so if a task's `xp` value changes later,
undoing an old completion still refunds the amount that was actually
granted — not the task's current value.
"""

from datetime import datetime

from app.extensions import db


class Completion(db.Model):
    __tablename__ = 'completions'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id', ondelete='CASCADE'), nullable=False, index=True)

    date = db.Column(db.Date, nullable=False, index=True)
    completed_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    points_awarded = db.Column(db.Integer, nullable=False, default=0)

    # ── Relationships ────────────────────────────────────────────────────
    user = db.relationship('User', back_populates='completions')
    task = db.relationship('Task', back_populates='completions')

    __table_args__ = (
        db.UniqueConstraint('user_id', 'task_id', 'date', name='uq_completions_user_task_date'),
        db.CheckConstraint('points_awarded >= 0', name='ck_completions_points_non_negative'),
    )

    def to_dict(self):
        return {
            'taskId': self.task_id,
            'date': self.date.isoformat() if self.date else None,
            'completedAt': self.completed_at.isoformat() if self.completed_at else None,
            'pointsAwarded': self.points_awarded,
        }

    def __repr__(self):
        return f'<Completion user_id={self.user_id} task_id={self.task_id} date={self.date}>'

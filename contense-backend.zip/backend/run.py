"""
Entry point.

    python run.py            # dev server
    flask --app run.py run   # equivalent, via Flask CLI

Gunicorn (production) points at `run:app`, e.g.:
    gunicorn 'run:app'
"""

import os

from app import create_app

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=app.config.get('DEBUG', False))
